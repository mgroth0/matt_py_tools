from mjlib.gui_example import AppWindow
