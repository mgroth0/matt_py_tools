class LivePlot:
    def __init__:
